# Aspen X2 Nashua — Grades Page Demo

A personal-use, front-end recreation inspired by the Nashua School District Aspen X2 Classes page.

## Run locally
Open `index.html` in a web browser.

## Publish with GitHub Pages
1. Create a new GitHub repository.
2. Upload `index.html` and this `README.md` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`, then save.

## Notes
- This is an independent demo and is not affiliated with Nashua School District or Follett.
- It does not connect to Aspen or access school records.
- All displayed student, course, and grade information is fictional sample data.
- Do not add real student information, login credentials, or private school records.
